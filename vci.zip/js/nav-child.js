/**
 * Created by Administrator on 2017/10/12.
 */
$(document).ready(function () {
    $("#nav").ferroMenu();
});